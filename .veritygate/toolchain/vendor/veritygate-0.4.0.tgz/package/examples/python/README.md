# Python 验收示例

需要 Python 3；测试只用标准库。复制本目录到自己的项目，在该目录执行：

```sh
veritygate audit > quality-report.md
```

配置中的 `python3` 可以改成机器上真实的 Python 可执行文件名或绝对路径。
`test_contract.py` 定义用户的六条验收条件；`shipping.py` 是待 AI 实现的代码。
把 `shipping.py` 中的 `>= 100` 改为 `> 100`，边界测试就会失败，审计退出码为 1。
改回实现后，再运行同一命令即可通过。验收脚本、配置和阈值保持不变。

这里只演示验收测试，不声称已经运行覆盖率、变异或静态分析。

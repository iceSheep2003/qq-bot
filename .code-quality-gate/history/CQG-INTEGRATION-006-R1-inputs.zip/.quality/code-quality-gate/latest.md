# Code Quality Gate workflow

**Phase:** red

**Phase accepted:** yes

**Ready to merge:** no

Failing assertions recorded; implement the behavior without changing the tests or standards

**Iteration history:** .quality/code-quality-gate/history.md

# Code quality report

**Status:** FAIL

| Check | Status | Metrics | Details |
| --- | --- | --- | --- |
| Released CQG 0.6.0 provenance and one active integration | FAILED | Integration cases: 4 (&gt;= 4); Success rate: 25 (= 100); Skipped: 0 (= 0) | Command exited with code 1<br>JUnit report contains 3 failed tests<br>Success rate: 25; required = 100 |

**Summary:** 0 passed, 1 failed, 0 errors; 1 blocking.

### Released CQG 0.6.0 provenance and one active integration

    .FFF                                                                     [100%]
    =================================== FAILURES ===================================
    __________ test_bundled_skill_and_managed_instructions_are_installed ___________
    
        def test_bundled_skill_and_managed_instructions_are_installed():
            with tarfile.open(TOOLCHAIN / "vendor/code-quality-gate-0.6.0.tgz") as archive:
                official = archive.extractfile("package/skills/code-quality-gate/SKILL.md").read()
            for relative in (".agents/skills/code-quality-gate/SKILL.md", ".claude/skills/code-quality-gate/SKILL.md"):
                path = ROOT / relative
    >           assert path.is_file(), relative
    E           AssertionError: .agents/skills/code-quality-gate/SKILL.md
    E           assert False
    E            +  where False = is_file()
    E            +    where is_file = PosixPath('/Users/ice.sheep/Documents/Codex/2026-09-22/ni/outputs/qq-companion-bot/.agents/skills/code-quality-gate/SKILL.md').is_file
    
    tests/quality/test_quality_integration.py:33: AssertionError
    ________________ test_ci_and_mcp_use_one_current_quality_engine ________________
    
        def test_ci_and_mcp_use_one_current_quality_engine():
            workflow = ROOT / ".github/workflows/code-quality-gate.yml"
    >       assert workflow.is_file()
    E       AssertionError: assert False
    E        +  where False = is_file()
    E        +    where is_file = PosixPath('/Users/ice.sheep/Documents/Codex/2026-09-22/ni/outputs/qq-companion-bot/.github/workflows/code-quality-gate.yml').is_file
    
    tests/quality/test_quality_integration.py:43: AssertionError
    ___________ test_old_engine_is_archived_without_a_second_active_tree ___________
    
        def test_old_engine_is_archived_without_a_second_active_tree():
    >       assert not (ROOT / ".veritygate").exists()
    E       AssertionError: assert not True
    E        +  where True = exists()
    E        +    where exists = (PosixPath('/Users/ice.sheep/Documents/Codex/2026-09-22/ni/outputs/qq-companion-bot') / '.veritygate').exists
    
    tests/quality/test_quality_integration.py:55: AssertionError
    =========================== short test summary info ============================
    FAILED tests/quality/test_quality_integration.py::test_bundled_skill_and_managed_instructions_are_installed
    FAILED tests/quality/test_quality_integration.py::test_ci_and_mcp_use_one_current_quality_engine
    FAILED tests/quality/test_quality_integration.py::test_old_engine_is_archived_without_a_second_active_tree
    3 failed, 1 passed in 0.38s

_Results apply to the executed checks and configured thresholds. They do not prove the absence of defects._

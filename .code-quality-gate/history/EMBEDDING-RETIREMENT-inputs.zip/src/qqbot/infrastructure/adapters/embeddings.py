"""Optional embedding HTTP adapter and deployment configuration."""
from __future__ import annotations
import logging
import os
from qqbot.agent.memory.embeddings import DEFAULT_HASH_DIM, EmbeddingProvider, HashingEmbedder

log = logging.getLogger(__name__)

class OpenAICompatibleEmbedder:
    """``POST {base_url}/embeddings`` — the same shape as the chat adapter."""

    def __init__(self, base_url: str, api_key: str, model: str, timeout: float = 5.0):
        import httpx

        self.name = model
        self._model = model
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def embed(self, texts: list[str]) -> list[list[float]] | None:
        try:
            response = self._client.post(
                "/embeddings", json={"model": self._model, "input": list(texts)}
            )
            response.raise_for_status()
            payload = response.json()
            data = sorted(payload["data"], key=lambda item: item.get("index", 0))
            return [list(item["embedding"]) for item in data]
        except Exception as exc:  # network, auth, schema — all mean "no vectors"
            log.warning("embedding request failed, falling back to lexical: %s", exc)
            return None

    def close(self) -> None:
        self._client.close()


def embeddings_from_env(env: dict | None = None) -> EmbeddingProvider | None:
    """Build the configured provider, or ``None`` when the vector path is off."""
    env = os.environ if env is None else env
    provider = (env.get("BOT_MEMORY_EMBEDDING_PROVIDER") or "").strip().lower()
    if not provider:
        return None
    try:
        if provider == "hash":
            return HashingEmbedder(int(env.get("BOT_MEMORY_EMBEDDING_DIM", DEFAULT_HASH_DIM)))
        if provider in ("openai", "openai-compatible"):
            model = (env.get("BOT_MEMORY_EMBEDDING_MODEL") or "").strip()
            if not model:
                log.warning(
                    "BOT_MEMORY_EMBEDDING_MODEL is required for provider=%s; "
                    "vector path disabled",
                    provider,
                )
                return None
            base_url = (
                env.get("BOT_MEMORY_EMBEDDING_BASE_URL")
                or env.get("BOT_MODEL_BASE_URL")
                or ""
            ).strip()
            api_key = (
                env.get("BOT_MEMORY_EMBEDDING_API_KEY")
                or env.get("BOT_MODEL_API_KEY")
                or ""
            )
            if not base_url:
                log.warning("no embedding base url configured; vector path disabled")
                return None
            return OpenAICompatibleEmbedder(base_url, api_key, model)
        log.warning("unknown BOT_MEMORY_EMBEDDING_PROVIDER=%s; vector path disabled", provider)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("embedding provider unavailable (%s); vector path disabled", exc)
    return None

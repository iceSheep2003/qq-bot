"""Optional embedding providers for hybrid retrieval.

The vector path is opt-in through the environment:

    BOT_MEMORY_EMBEDDING_PROVIDER = "" (default) | openai | hash
    BOT_MEMORY_EMBEDDING_BASE_URL   defaults to BOT_MODEL_BASE_URL
    BOT_MEMORY_EMBEDDING_API_KEY    defaults to BOT_MODEL_API_KEY
    BOT_MEMORY_EMBEDDING_MODEL      required for the openai provider
    BOT_MEMORY_EMBEDDING_DIM        optional, hash provider width

When nothing is configured ``embeddings_from_env()`` returns ``None`` and no
vector code runs at all. Every provider is defensive: a failure returns ``None``
and the caller falls back to lexical search. Nothing here may raise at import
or construction time — a broken endpoint must not stop the bot from starting.
"""

from __future__ import annotations

import hashlib
from typing import Protocol


DEFAULT_HASH_DIM = 256


class EmbeddingProvider(Protocol):
    name: str

    def embed(self, texts: list[str]) -> list[list[float]] | None: ...


class HashingEmbedder:
    """Deterministic local embedder: hashed character bigrams.

    Not semantic, but it needs no network, so it exercises the vector path in
    tests and lets a deployment run hybrid retrieval offline.
    """

    def __init__(self, dim: int = DEFAULT_HASH_DIM):
        self.dim = max(32, int(dim))
        self.name = f"hash-{self.dim}"

    def embed(self, texts: list[str]) -> list[list[float]] | None:
        from qqbot.agent.memory.text import char_ngrams

        vectors: list[list[float]] = []
        for text in texts:
            vector = [0.0] * self.dim
            grams = char_ngrams(text) or {text}
            for gram in grams:
                digest = hashlib.sha1(gram.encode("utf-8")).digest()
                bucket = int.from_bytes(digest[:4], "big") % self.dim
                sign = 1.0 if digest[4] % 2 else -1.0
                vector[bucket] += sign
            vectors.append(vector)
        return vectors



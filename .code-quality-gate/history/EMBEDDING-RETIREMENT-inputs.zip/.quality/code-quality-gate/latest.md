# Code Quality Gate workflow

**Phase:** green

**Phase accepted:** no

**Ready to merge:** no

Implementation must change from red, pass all checks, and remain unchanged while checks run

**Iteration history:** .quality/code-quality-gate/history.md

# Code quality report

**Status:** FAIL

| Check | Status | Metrics | Details |
| --- | --- | --- | --- |
| Frozen scene-core acceptance | PASSED | Acceptance cases: 40 (&gt;= 35); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Owner skill exclusion before selection budget | PASSED | Owner boundary cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Kinna bot public identity and existing CLI compatibility | PASSED | Branding cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Canonical source, dependency boundaries, preserved tests and installable wheel | PASSED | Layout acceptance cases: 21 (&gt;= 20); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| QQ Bot package identity and deployment compatibility | PASSED | Package identity cases: 10 (&gt;= 5); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Released CQG 0.6.0 provenance and one active integration | PASSED | Integration cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Independent post-reply observation lifecycle and service delegation | PASSED | Observation cases: 23 (&gt;= 18); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Memory extraction, compaction and service shutdown ownership | PASSED | Maintenance cases: 28 (&gt;= 28); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Single outbound delivery owner and explicit observation repository | PASSED | Acceptance cases: 10 (&gt;= 9); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Deferred worker lifecycle and QQ event routing | PASSED | Acceptance cases: 13 (&gt;= 13); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Pure Agent dependencies, canonical policy and explicit I/O adapters | PASSED | Acceptance cases: 11 (&gt;= 10); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Complete legacy and new Python regression suite | FAILED | Regression cases: 1370 (&gt;= 1202); Success rate: 99.49 (= 100); Skipped: 0 (= 0) | Command exited with code 1<br>JUnit report contains 7 failed tests<br>Success rate: 99.48905109489051; required = 100 |
| Ruff syntax and correctness across changed Python modules | PASSED | — | — |
| Import-linter ownership contracts | PASSED | — | — |
| New module line and branch coverage | PASSED | Line coverage: 98.77 (&gt;= 90); Branch coverage: 94.44 (&gt;= 80); Statements: 81 (&gt;= 20); Branches: 18 (&gt;= 10) | — |
| Observation module measured line and branch coverage | PASSED | Line coverage: 99.41 (&gt;= 90); Branch coverage: 92.59 (&gt;= 80); Statements: 169 (&gt;= 100); Branches: 54 (&gt;= 40) | — |
| Independent maintenance module coverage | PASSED | Line coverage: 100 (&gt;= 90); Branch coverage: 100 (&gt;= 80); Statements: 80 (&gt;= 40); Branches: 16 (&gt;= 16) | — |
| Single outbound delivery owner and explicit observation repository measured coverage | PASSED | Line coverage: 96.55 (&gt;= 90); Branch coverage: 81.82 (&gt;= 80); Statements: 58 (&gt;= 20); Branches: 22 (&gt;= 4) | — |
| Deferred worker lifecycle and QQ event routing measured coverage | PASSED | Line coverage: 96.43 (&gt;= 90); Branch coverage: 95.45 (&gt;= 80); Statements: 84 (&gt;= 20); Branches: 22 (&gt;= 4) | — |

**Summary:** 18 passed, 1 failed, 0 errors; 1 blocking.

### Complete legacy and new Python regression suite

    .................................................................... [  4%]
    ...................................................................... [ 10%]
    ........................................................................ [ 15%]
    ........................................................................ [ 20%]
    .................................FF.......................................................................... [ 28%]
    ............................................................... [ 33%]
    ............................................................................. [ 38%]
    .................................................... [ 42%]
    ........................................................... [ 46%]
    ............................................................................................. [ 53%]
    .......................................................... [ 57%]
    ............................ [ 59%]
    ........................................................................................................ [ 67%]
    .......................................................FFFF... [ 72%]
    .............................................................................. [ 77%]
    .................................................................................................................................................................................. [ 90%]
    ........................................................................ [ 95%]
    .............F.........................................                  [100%]
    =================================== FAILURES ===================================
    ________________ ProactiveGateTests.test_sociable_bot_joins_in _________________
    
    self = <tests.agent.test_emotion.ProactiveGateTests testMethod=test_sociable_bot_joins_in>
    
        def test_sociable_bot_joins_in(self):
            self.assertEqual(
    >           [m["text"] for m in self.run_proactive(withdraw=False)], ["收到。"]
                                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            )
    
    tests/agent/test_emotion.py:349: 
    _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
    tests/agent/test_emotion.py:337: in run_proactive
        self.service(emotions, sender), ProactiveConfig(), emotions
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
    
    self = <tests.agent.test_emotion.ProactiveGateTests testMethod=test_sociable_bot_joins_in>
    emotions = <qqbot.agent.identity.emotion.system.EmotionSystem object at 0x12299c160>
    sender = <tests.agent.test_emotion.RecordingSender object at 0x116d99e80>
    
        def service(self, emotions, sender):
            from qqbot.agent.orchestrator import Agent
            from qqbot.agent.service import ConversationService
            from tests.support import bot_policy
            from qqbot.agent.skills.catalog import SkillCatalog
            from qqbot.actions.tools.registry import built_in_tools
        
            agent = Agent(
                StubModel(),
                self.store,
                self.store,
                MemoryService(StubModel(), self.store, self.store),
                SkillCatalog(self.root / "skills"),
                built_in_tools(self.store),
                self.persona,
            )
    >       policy_ = bot_policy(
                frozenset({"42"}),
                8,
                "Asia/Shanghai",
                False,
                False,
                6,
                0,
                24,
                30,
                180,
                150,
            )
    E       TypeError: bot_policy() takes from 4 to 5 positional arguments but 11 were given
    
    tests/agent/test_emotion.py:293: TypeError
    ______________ ProactiveGateTests.test_withdrawn_bot_stays_quiet _______________
    
    self = <tests.agent.test_emotion.ProactiveGateTests testMethod=test_withdrawn_bot_stays_quiet>
    
        def test_withdrawn_bot_stays_quiet(self):
    >       self.assertEqual(self.run_proactive(withdraw=True), [])
                             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    
    tests/agent/test_emotion.py:345: 
    _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
    tests/agent/test_emotion.py:337: in run_proactive
        self.service(emotions, sender), ProactiveConfig(), emotions
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
    
    self = <tests.agent.test_emotion.ProactiveGateTests testMethod=test_withdrawn_bot_stays_quiet>
    emotions = <qqbot.agent.identity.emotion.system.EmotionSystem object at 0x122af4450>
    sender = <tests.agent.test_emotion.RecordingSender object at 0x110f09d10>
    
        def service(self, emotions, sender):
            from qqbot.agent.orchestrator import Agent
            from qqbot.agent.service import ConversationService
            from tests.support import bot_policy
            from qqbot.agent.skills.catalog import SkillCatalog
            from qqbot.actions.tools.registry import built_in_tools
        
            agent = Agent(
                StubModel(),
                self.store,
                self.store,
                MemoryService(StubModel(), self.store, self.store),
                SkillCatalog(self.root / "skills"),
                built_in_tools(self.store),
                self.persona,
            )
    >       policy_ = bot_policy(
                frozenset({"42"}),
                8,
                "Asia/Shanghai",
                False,
                False,
                6,
                0,
                24,
                30,
                180,
                150,
            )
    E       TypeError: bot_policy() takes from 4 to 5 positional arguments but 11 were given
    
    tests/agent/test_emotion.py:293: TypeError
    _ ReplyPolicyServiceTests.test_a_broken_admission_policy_fails_closed_before_the_model _
    
    self = <tests.features.test_reply_policy.ReplyPolicyServiceTests testMethod=test_a_broken_admission_policy_fails_closed_before_the_model>
    
        def test_a_broken_admission_policy_fails_closed_before_the_model(self):
            class Exploding:
                async def decide(self, event, *, recent):
                    raise RuntimeError("policy exploded")
        
            with tempf

_Results apply to the executed checks and configured thresholds. They do not prove the absence of defects._

# VerityGate workflow

**Phase:** green

**Phase accepted:** no

**Ready to merge:** no

Implementation must change from red, pass all checks, and remain unchanged while checks run

# Code quality report

**Status:** FAIL

| Check | Status | Metrics | Details |
| --- | --- | --- | --- |
| Frozen scene-core acceptance | PASSED | Acceptance cases: 40 (&gt;= 35); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Owner skill exclusion before selection budget | PASSED | Owner boundary cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Kinna bot public identity and existing CLI compatibility | PASSED | Branding cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Canonical source, dependency boundaries, preserved tests and installable wheel | PASSED | Layout acceptance cases: 21 (&gt;= 20); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| QQ Bot package identity and deployment compatibility | PASSED | Package identity cases: 10 (&gt;= 5); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Complete legacy and new Python regression suite | FAILED | Regression cases: 1280 (&gt;= 1202); Success rate: 99.92 (= 100); Skipped: 0 (= 0) | Command exited with code 1<br>JUnit report contains 1 failed tests<br>Success rate: 99.921875; required = 100 |
| Ruff syntax and correctness across changed Python modules | PASSED | — | — |
| Import-linter ownership contracts | PASSED | — | — |
| New module line and branch coverage | PASSED | Line coverage: 98.77 (&gt;= 90); Branch coverage: 94.44 (&gt;= 80); Statements: 81 (&gt;= 20); Branches: 18 (&gt;= 10) | — |

**Summary:** 8 passed, 1 failed, 0 errors; 1 blocking.

### Complete legacy and new Python regression suite

    .................................................................... [  5%]
    ...................................................................... [ 10%]
    ........................................................................ [ 16%]
    ................................................................ [ 21%]
    ................................................................................................................................ [ 31%]
    ................................................................ [ 36%]
    .......... [ 37%]
    .................................................... [ 41%]
    ........................................................... [ 45%]
    ........................................ [ 48%]
    ........F............................................ [ 53%]
    ...................................................................................... [ 59%]
    ........................................ [ 62%]
    ................................................................ [ 67%]
    ............................................................................................................................................ [ 78%]
    .............................................. [ 82%]
    ............................................................ [ 87%]
    ........................................................................ [ 92%]
    ........................................................................ [ 98%]
    ....................                                                     [100%]
    =================================== FAILURES ===================================
    ________ SpecificationSnapshotTests.test_v1_draft_contract_fingerprints ________
    
    self = <tests.contracts.test_kernel_contracts.SpecificationSnapshotTests testMethod=test_v1_draft_contract_fingerprints>
    
        def test_v1_draft_contract_fingerprints(self):
            expected = json.loads((Path(__file__).parent / "kernel_v1_snapshot.json").read_text())
            actual = {"ontology": v1.specification_hash(), "tools": kernel_v1.specification_hash(),
                      "lifecycles": lifecycle.specification_hash(), "extensions": extension_inputs.specification_hash()}
    >       self.assertEqual(expected["fingerprints"], actual, "Contract changed: review and explicitly update the version/snapshot")
    E       AssertionError: {'ontology': '140bb89b49289e267efd605a4ed9b5c5fb32980dc[261 chars]520'} != {'ontology': 'bb524c7c128aade75087b6da2a5620a3e188b58af[261 chars]dbd'}
    E       - {'extensions': '1a919400aa1fc2e964117285db5ec0ea8f5154e86b92f50469b1dcc52dea0520',
    E       + {'extensions': '650f78b4cafab6abc7fe441931ad825a37b3e6a66fabdddd10d071cda6b25dbd',
    E          'lifecycles': '7880e1b27e60d43393ed777d1542807f0331992a765ba3b32c32ab69415ad20a',
    E       -  'ontology': '140bb89b49289e267efd605a4ed9b5c5fb32980dc707eeed57bc27d09978a8c1',
    E       -  'tools': '17f72e0682605671c2b2d0d9a1ce7cc414531051db0777ad4eadd1136c67e867'}
    E       +  'ontology': 'bb524c7c128aade75087b6da2a5620a3e188b58af2a105fc411007e5c9c82a94',
    E       +  'tools': '976ca3aea05b22981a667b5e9b160633ae990b1dded860ad51350f1742787b95'} : Contract changed: review and explicitly update the version/snapshot
    
    tests/contracts/test_kernel_contracts.py:339: AssertionError
    =============================== warnings summary ===============================
    tests/agent/test_integration.py::AssemblyTests::test_a_silent_contributor_is_absent_from_both_halves
    tests/agent/test_integration.py::AssemblyTests::test_contributions_carry_their_declared_trust
    tests/agent/test_integration.py::AssemblyTests::test_every_extension_can_be_enabled_at_once
    tests/agent/test_integration.py::AssemblyTests::test_feature_binders_ran_against_the_live_service
    tests/agent/test_integration.py::AssemblyTests::test_reply_policy_is_absent_when_switched_off
    tests/agent/test_integration.py::AssemblyTests::test_reply_policy_is_installed_when_enabled
    tests/agent/test_integration.py::AssemblyTests::test_shutdown_reaches_the_service
      /opt/homebrew/Cellar/python@3.14/3.14.3_1/Frameworks/Python.framework/Versions/3.14/lib/python3.14/unittest/case.py:615: RuntimeWarning: coroutine '_supervise.<locals>.supervised' was never awaited
        result = method()
      Enable tracemalloc to get traceback where the object was allocated.
      See https://docs.pytest.org/en/stable/how-to/capture-warnings.html#resource-warnings for more info.
    
    -- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
    =========================== short test summary info ============================
    FAILED tests/contracts/test_kernel_contracts.py::SpecificationSnapshotTests::test_v1_draft_contract_fingerprints
    1 failed, 1279 passed, 7 warnings, 972 subtests passed in 28.01s

_Results apply to the executed checks and configured thresholds. They do not prove the absence of defects._

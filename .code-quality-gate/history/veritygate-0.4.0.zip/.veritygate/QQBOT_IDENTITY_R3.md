# Naming R3: user requires complete convergence

The user explicitly rejected keeping new and old naming together after R2 red.
This supersedes the earlier compatibility decision: remove the old CLI alias,
old Python namespace, old source directory, old session-key identifier and old
default filename from live code. Official commands are qqbot and kinna-bot;
distribution is kinna-bot; import namespace is qqbot.

The canonical new database default is data/qqbot.sqlite3. Preserve every explicit
BOT_DB_PATH. Startup and --check must refuse to create that default when another
SQLite database exists in data and the canonical file is absent. Ask the operator
to select a path explicitly; do not rename live databases, open a silent empty
store, or migrate credentials. A new storage-selection validation method belongs
to bootstrap/config.py and is called before opening resources at both entry
points. This is selection validation, not a second storage implementation.

Acceptance covers fresh install, existing canonical file, explicit existing path,
application/--check upgrade refusal, absence of old command and source identifiers,
and absence of old package files in an actual built wheel. Existing behavior
tests keep their names/assertion counts and all thresholds stay unchanged.

R1 and R2 evidence and exact inputs are archived. They had no green attempts;
this is a user-directed scope revision, not a budget reset. R3 red runs against
the partly renamed implementation and its still-present legacy alias/default,
then freezes the stricter acceptance before completing implementation.

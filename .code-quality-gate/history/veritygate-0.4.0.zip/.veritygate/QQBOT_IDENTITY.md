# QQ Bot package naming

User explicitly requested QQ Bot or Bot instead of the mixed pinyin/English
qunbot package name. Product name stays Kinna bot; distribution becomes
kinna-bot, canonical Python package becomes qqbot under src/qqbot. New commands
qqbot and kinna-bot use qqbot.bootstrap.app:main. Keep qunbot only as a legacy
CLI alias, not as a duplicate Python namespace or a sys.modules proxy.

All production imports, test imports, tool imports, package data paths, source
references and import-linter roots are migrated. Real database files, default
data/qunbot.sqlite3, environment variable names and persisted browser session
keys do not move. Existing behavior tests keep their names/assertion counts.
The previous layout task and its evidence are committed at 9d7cccd and retained.

Acceptance is written before the rename. It checks the actual import location,
absence of the old package, explicit distribution/entry points, no old source
imports, three working installed commands and unchanged database selection.
The existing wheel test verifies every module and resource under qqbot from
outside the checkout. All prior quality checks and thresholds remain mandatory.
Teaching material is updated outside this repository and is not committed.

# Naming R2: retain the existing negative brand assertion

Before implementation, review found that the test-import migration had also
replaced the literal QunBot inside an existing negative branding assertion with
Kinna bot. That contradicted the positive Kinna bot assertions in the same test.
Restore the original forbidden QunBot literal, retaining every original assertion
and test name. This is not a product behavior change or a relaxed expectation.

Original R1 inputs and red evidence are archived unchanged. No R1 green
attempts were consumed. Production still has src/qunbot, so R2 records its own
five genuine naming assertion failures before the namespace is moved. All
quality checks and thresholds stay unchanged.

# Code Quality Gate workflow

**Phase:** green

**Phase accepted:** no

**Ready to merge:** no

Implementation must change from red, pass all checks, and remain unchanged while checks run

**Iteration history:** .quality/code-quality-gate/history.md

# Code quality report

**Status:** FAIL

| Check | Status | Metrics | Details |
| --- | --- | --- | --- |
| Frozen scene-core acceptance | PASSED | Acceptance cases: 40 (&gt;= 35); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Owner skill exclusion before selection budget | PASSED | Owner boundary cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Kinna bot public identity and existing CLI compatibility | PASSED | Branding cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Canonical source, dependency boundaries, preserved tests and installable wheel | PASSED | Layout acceptance cases: 21 (&gt;= 20); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| QQ Bot package identity and deployment compatibility | PASSED | Package identity cases: 10 (&gt;= 5); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Released CQG 0.6.0 provenance and one active integration | PASSED | Integration cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Independent post-reply observation lifecycle and service delegation | PASSED | Observation cases: 23 (&gt;= 18); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Memory extraction, compaction and service shutdown ownership | PASSED | Maintenance cases: 28 (&gt;= 28); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Single outbound delivery owner and explicit observation repository | PASSED | Acceptance cases: 10 (&gt;= 9); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Deferred worker lifecycle and QQ event routing | PASSED | Acceptance cases: 13 (&gt;= 13); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Pure Agent dependencies, canonical policy and explicit I/O adapters | PASSED | Acceptance cases: 11 (&gt;= 10); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Embedding removal with non-destructive historical data compatibility | PASSED | Acceptance cases: 8 (&gt;= 8); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Complete legacy and new Python regression suite | FAILED | Regression cases: 1458 (&gt;= 1202); Success rate: 99.93 (= 100); Skipped: 0 (= 0) | Command exited with code 1<br>JUnit report contains 1 failed tests<br>Success rate: 99.93141289437585; required = 100 |
| Ruff syntax and correctness across changed Python modules | PASSED | — | — |
| Import-linter ownership contracts | PASSED | — | — |
| New module line and branch coverage | PASSED | Line coverage: 98.77 (&gt;= 90); Branch coverage: 94.44 (&gt;= 80); Statements: 81 (&gt;= 20); Branches: 18 (&gt;= 10) | — |
| Observation module measured line and branch coverage | PASSED | Line coverage: 99.41 (&gt;= 90); Branch coverage: 92.59 (&gt;= 80); Statements: 169 (&gt;= 100); Branches: 54 (&gt;= 40) | — |
| Independent maintenance module coverage | PASSED | Line coverage: 100 (&gt;= 90); Branch coverage: 100 (&gt;= 80); Statements: 80 (&gt;= 40); Branches: 16 (&gt;= 16) | — |
| Single outbound delivery owner and explicit observation repository measured coverage | PASSED | Line coverage: 96.55 (&gt;= 90); Branch coverage: 81.82 (&gt;= 80); Statements: 58 (&gt;= 20); Branches: 22 (&gt;= 4) | — |
| Deferred worker lifecycle and QQ event routing measured coverage | PASSED | Line coverage: 96.43 (&gt;= 90); Branch coverage: 95.45 (&gt;= 80); Statements: 84 (&gt;= 20); Branches: 22 (&gt;= 4) | — |
| Wiki private ownership and cached selection budgets | PASSED | Cases: 7 (&gt;= 7); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Default private chat instructions and audience isolation | PASSED | Cases: 3 (&gt;= 3); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Persistent private distinct-user limit before model and memory work | PASSED | Cases: 7 (&gt;= 7); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Automatic person continuity with no chat control surface | PASSED | Cases: 21 (&gt;= 21); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Retire owned Wiki pages without deleting manual content | FAILED | Cases: 8 (&gt;= 8); Success rate: 87.50 (= 100); Skipped: 0 (= 0) | Command exited with code 1<br>JUnit report contains 1 failed tests<br>Success rate: 87.5; required = 100 |

**Summary:** 23 passed, 2 failed, 0 errors; 2 blocking.

### Complete legacy and new Python regression suite

    .................................................................... [  4%]
    ...................................................................... [  9%]
    ........................................................................ [ 14%]
    ........................................................................ [ 19%]
    ................................................................................................................ [ 27%]
    ............................................................. [ 31%]
    ..................................................................... [ 35%]
    .............................................................. [ 40%]
    ................................................................... [ 44%]
    ....................................F...................... [ 48%]
    ............................................................................................. [ 55%]
    .......................................................... [ 59%]
    ............................ [ 61%]
    ........................................................................................................ [ 68%]
    .............................................................. [ 72%]
    .............................................................................. [ 77%]
    .................................................................................................................... [ 85%]
    .............................................................. [ 90%]
    ........................................................................ [ 94%]
    ........................................................................ [ 99%]
    .                                                                        [100%]
    =================================== FAILURES ===================================
    ___ test_forced_sync_removes_retired_page_and_invalidates_warm_reader_cache ____
    
    tmp_path = PosixPath('/private/var/folders/c4/3t_9rjd96wq2d9n2mvb7pn9h0000gn/T/pytest-of-ice.sheep/pytest-280/test_forced_sync_removes_retir0')
    
        def test_forced_sync_removes_retired_page_and_invalidates_warm_reader_cache(tmp_path):
            snapshot = rows()
            sync = LegacyWikiSynchronizer(lambda: snapshot, tmp_path)
            sync.refresh(force=True)
            reader = FileBackedWikiReader(tmp_path, ttl_seconds=300)
            assert reader.read("group:1", "7", "事实")["entries"]
            snapshot["memories"].clear()
            sync.refresh(force=True)
    >       assert reader.read("group:1", "7", "事实")["entries"] == []
    E       AssertionError: assert [{'entry_id':... 'fact', ...}] == []
    E         
    E         Left contains 2 more items, first extra item: {'entry_id': 'parsed-0', 'claim': '群的事实', 'topic': '', 'fact_type': 'fact', ...}
    E         Use -v to get more diff
    
    tests/agent/test_wiki_snapshot_replacement.py:73: AssertionError
    =========================== short test summary info ============================
    FAILED tests/agent/test_wiki_snapshot_replacement.py::test_forced_sync_removes_retired_page_and_invalidates_warm_reader_cache
    1 failed, 1457 passed, 919 subtests passed in 31.45s

### Retire owned Wiki pages without deleting manual content

    ......F.                                                                 [100%]
    =================================== FAILURES ===================================
    ___ test_forced_sync_removes_retired_page_and_invalidates_warm_reader_cache ____
    
    tmp_path = PosixPath('/private/var/folders/c4/3t_9rjd96wq2d9n2mvb7pn9h0000gn/T/pytest-of-ice.sheep/pytest-283/test_forced_sync_removes_retir0')
    
        def test_forced_sync_removes_retired_page_and_invalidates_warm_reader_cache(tmp_path):
            snapshot = rows()
            sync = LegacyWikiSynchronizer(lambda: snapshot, tmp_path)
            sync.refresh(force=True)
            reader = FileBackedWikiReader(tmp_path, ttl_seconds=300)
            assert reader.read("group:1", "7", "事实")["entries"]
            snapshot["memories"].clear()
            sync.refresh(force=True)
    >       assert reader.read("group:1", "7", "事实")["entries"] == []
    E       AssertionError: assert [{'entry_id':... 'fact', ...}] == []
    E         
    E         Left contains 2 more items, first extra item: {'entry_id': 'parsed-0', 'claim': '群的事实', 'topic': '', 'fact_type': 'fact', ...}
    E         Use -v to get more diff
    
    tests/agent/test_wiki_snapshot_replacement.py:73: AssertionError
    =========================== short test summary info ============================
    FAILED tests/agent/test_wiki_snapshot_replacement.py::test_forced_sync_removes_retired_page_and_invalidates_warm_reader_cache
    1 failed, 7 passed in 0.14s

_Results apply to the executed checks and configured thresholds. They do not prove the absence of defects._

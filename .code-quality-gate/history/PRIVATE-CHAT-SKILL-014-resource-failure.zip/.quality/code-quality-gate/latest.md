# Code Quality Gate workflow

**Phase:** green

**Phase accepted:** no

**Ready to merge:** no

Implementation must change from red, pass all checks, and remain unchanged while checks run

**Iteration history:** .quality/code-quality-gate/history.md

# Code quality report

**Status:** FAIL

| Check | Status | Metrics | Details |
| --- | --- | --- | --- |
| Frozen scene-core acceptance | PASSED | Acceptance cases: 40 (&gt;= 35); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Owner skill exclusion before selection budget | PASSED | Owner boundary cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Kinna bot public identity and existing CLI compatibility | PASSED | Branding cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Canonical source, dependency boundaries, preserved tests and installable wheel | PASSED | Layout acceptance cases: 21 (&gt;= 20); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| QQ Bot package identity and deployment compatibility | PASSED | Package identity cases: 10 (&gt;= 5); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Released CQG 0.6.0 provenance and one active integration | PASSED | Integration cases: 4 (&gt;= 4); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Independent post-reply observation lifecycle and service delegation | PASSED | Observation cases: 23 (&gt;= 18); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Memory extraction, compaction and service shutdown ownership | PASSED | Maintenance cases: 28 (&gt;= 28); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Single outbound delivery owner and explicit observation repository | PASSED | Acceptance cases: 10 (&gt;= 9); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Deferred worker lifecycle and QQ event routing | PASSED | Acceptance cases: 13 (&gt;= 13); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Pure Agent dependencies, canonical policy and explicit I/O adapters | PASSED | Acceptance cases: 11 (&gt;= 10); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Embedding removal with non-destructive historical data compatibility | PASSED | Acceptance cases: 8 (&gt;= 8); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Complete legacy and new Python regression suite | FAILED | Regression cases: 1422 (&gt;= 1202); Success rate: 99.93 (= 100); Skipped: 0 (= 0) | Command exited with code 1<br>JUnit report contains 1 failed tests<br>Success rate: 99.929676511955; required = 100 |
| Ruff syntax and correctness across changed Python modules | PASSED | — | — |
| Import-linter ownership contracts | PASSED | — | — |
| New module line and branch coverage | PASSED | Line coverage: 98.77 (&gt;= 90); Branch coverage: 94.44 (&gt;= 80); Statements: 81 (&gt;= 20); Branches: 18 (&gt;= 10) | — |
| Observation module measured line and branch coverage | PASSED | Line coverage: 99.41 (&gt;= 90); Branch coverage: 92.59 (&gt;= 80); Statements: 169 (&gt;= 100); Branches: 54 (&gt;= 40) | — |
| Independent maintenance module coverage | PASSED | Line coverage: 100 (&gt;= 90); Branch coverage: 100 (&gt;= 80); Statements: 80 (&gt;= 40); Branches: 16 (&gt;= 16) | — |
| Single outbound delivery owner and explicit observation repository measured coverage | PASSED | Line coverage: 96.55 (&gt;= 90); Branch coverage: 81.82 (&gt;= 80); Statements: 58 (&gt;= 20); Branches: 22 (&gt;= 4) | — |
| Deferred worker lifecycle and QQ event routing measured coverage | PASSED | Line coverage: 96.43 (&gt;= 90); Branch coverage: 95.45 (&gt;= 80); Statements: 84 (&gt;= 20); Branches: 22 (&gt;= 4) | — |
| Wiki private ownership and cached selection budgets | PASSED | Cases: 7 (&gt;= 7); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |
| Default private chat instructions and audience isolation | PASSED | Cases: 3 (&gt;= 3); Success rate: 100 (= 100); Skipped: 0 (= 0) | — |

**Summary:** 21 passed, 1 failed, 0 errors; 1 blocking.

### Complete legacy and new Python regression suite

    .................................................................... [  4%]
    ...................................................................... [  9%]
    ........................................................................ [ 14%]
    ........................................................................ [ 19%]
    .................................................................................................................. [ 27%]
    ............................................................. [ 32%]
    ..................................................................... [ 36%]
    ......................................................... [ 40%]
    ........................................................................ [ 46%]
    ..................................................................................................................................................... [ 56%]
    ..................................................................................................................................................................................................................................................................... [ 74%]
    ........................................................................ [ 79%]
    .............................................. [ 83%]
    ............................................................ [ 87%]
    ........................................................................ [ 92%]
    .....................................................................F.. [ 97%]
    ...................................                                      [100%]
    =================================== FAILURES ===================================
    __________ test_application_and_developer_tools_do_not_import_qunbot ___________
    
    self = <http.client.HTTPResponse object at 0x112e03eb0>
    
        def close(self):
            try:
    >           super().close() # set "closed" flag
                ^^^^^^^^^^^^^^^
    
    /opt/homebrew/Cellar/python@3.14/3.14.3_1/Frameworks/Python.framework/Versions/3.14/lib/python3.14/http/client.py:437: 
    _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
    
    self = <http.client.HTTPResponse object at 0x112e03eb0>
    
        def flush(self):
            super().flush()
            if self.fp:
    >           self.fp.flush()
    E           ValueError: I/O operation on closed file.
    
    /opt/homebrew/Cellar/python@3.14/3.14.3_1/Frameworks/Python.framework/Versions/3.14/lib/python3.14/http/client.py:450: ValueError
    
    The above exception was the direct cause of the following exception:
    
    cls = <class '_pytest.runner.CallInfo'>
    func = <function call_and_report.<locals>.<lambda> at 0x1213107d0>
    when = 'call'
    reraise = (<class '_pytest.outcomes.Exit'>, <class 'KeyboardInterrupt'>)
    
        @classmethod
        def from_call(
            cls,
            func: Callable[[], TResult],
            when: Literal["collect", "setup", "call", "teardown"],
            reraise: type[BaseException] | tuple[type[BaseException], ...] | None = None,
        ) -> CallInfo[TResult]:
            """Call func, wrapping the result in a CallInfo.
        
            :param func:
                The function to call. Called without arguments.
            :type func: Callable[[], _pytest.runner.TResult]
            :param when:
                The phase in which the function is called.
            :param reraise:
                Exception or exceptions that shall propagate if raised by the
                function, instead of being wrapped in the CallInfo.
            """
            excinfo = None
            instant = timing.Instant()
            try:
    >           result: TResult | None = func()
                                         ^^^^^^
    
    .venv/lib/python3.14/site-packages/_pytest/runner.py:361: 
    _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
    .venv/lib/python3.14/site-packages/_pytest/runner.py:250: in <lambda>
        lambda: runtest_hook(item=item, **kwds),
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    .venv/lib/python3.14/site-packages/pluggy/_hooks.py:512: in __call__
        return self._hookexec(self.name, self._hookimpls.copy(), kwargs, firstresult)
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    .venv/lib/python3.14/site-packages/pluggy/_manager.py:120: in _hookexec
        return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    .venv/lib/python3.14/site-packages/_pytest/logging.py:865: in pytest_runtest_call
        yield
    .venv/lib/python3.14/site-packages/_pytest/capture.py:900: in pytest_runtest_call
        return (yield)
                ^^^^^
    .venv/lib/python3.14/site-packages/_pytest/skipping.py:268: in pytest_runtest_call
        return (yield)
                ^^^^^
    .venv/lib/python3.14/site-packages/_pytest/unraisableexception.py:183: in pytest_runtest_call
        collect_unraisable(item.config)
    .venv/lib/python3.14/site-packages/_pytest/unraisableexception.py:79: in collect_unraisable
        raise errors[0]
    _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
    
    config = <_pytest.config.Config object at 0x1068e3cb0>
    
        def collect_unraisable(config: Config) -> None:
            pop_unraisable = config.stash[unraisable_exceptions].pop
            errors: list[pytest.PytestUnraisableExceptionWarning | RuntimeError] = []
            meta = None
            hook_error = None
            try:
                while True:
                    try:
                        meta = pop_unraisable()
                    except IndexError:
                        break
        
                    if isinstance(meta, BaseException):
                        hook_error = RuntimeError("Failed to process unraisable exception")
                        hook_error.__cause__ = meta
                        errors.append(hook_error)
                        continue
        
                    msg = meta.msg
                    try:
    >                   warnings.warn(pytest.PytestUnraisableExceptionWarning(msg))
    E                   pytest.PytestUnraisableExceptionWarning: Exception ignored while finalizing file <http.client.HTTPRespon

_Results apply to the executed checks and configured thresholds. They do not prove the absence of defects._
